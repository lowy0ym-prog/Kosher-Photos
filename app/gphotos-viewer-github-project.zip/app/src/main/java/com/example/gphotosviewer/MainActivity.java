package com.example.gphotosviewer;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.webkit.CookieManager;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class MainActivity extends Activity {

    private WebView webView;

    // Any URL containing one of these pieces of text gets blocked.
    // I could not verify the real "create album" URL myself (no logged-in
    // session to inspect) - test this yourself and adjust the list below:
    //   1. Open photos.google.com in a normal browser.
    //   2. Try to create an album.
    //   3. Copy a unique piece of the address bar URL.
    //   4. Add it to this list.
    private static final String[] BLOCKED_URL_CONTAINS = {
        "/create",
        "printstore",
        "partnersharing",
        "shareablelink",
        "assistant"
    };

    private static final String START_URL = "https://photos.google.com/";

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView = (WebView) findViewById(R.id.webview);

        // Cookies on so your login session is remembered between launches.
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);

        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setDatabaseEnabled(true);
        webView.getSettings().setLoadWithOverviewMode(true);
        webView.getSettings().setUseWideViewPort(true);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();
                for (String piece : BLOCKED_URL_CONTAINS) {
                    if (url.toLowerCase().contains(piece.toLowerCase())) {
                        Log.d("GPhotosViewer", "Blocked navigation to: " + url);
                        Toast.makeText(MainActivity.this,
                                "This page is disabled in this app.",
                                Toast.LENGTH_SHORT).show();
                        return true; // cancel navigation
                    }
                }
                return false; // allow it
            }
        });

        webView.loadUrl(START_URL);
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
